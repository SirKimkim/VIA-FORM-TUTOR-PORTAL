// Leave empty to use the built-in Netlify server (recommended).
// Only paste a Google Web App address here if you use the FALLBACK-google-backend option.
window.VIRAJ_API = "";
